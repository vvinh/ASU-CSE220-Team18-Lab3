/********************************************
 *
 * CSE220 LS 12166 Lab3 - Team18
 * Nicholas Murray
 * Vivian Vinh
 * Timothy Zamora
 *
 **********************************************/

#ifndef Lab3_print_h
#define Lab3_print_h

#include "common.h"

void print_line(char *, char source_name[], char date_to_print[]);
void print_token(Token *token);
void init_scanner2(char source_name[], char date[]);

#endif

