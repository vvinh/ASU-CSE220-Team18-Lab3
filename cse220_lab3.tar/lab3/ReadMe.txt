>>>> To build and run this program:

>> make sure all the belows files are in the same directory:

main.c
print.c
scanner.c
Makefile
common.h
print.h
scanner.h
NEWTON.PAS
ActualOutput.txt

>> run the below command to clean

make clean

>> run the below command to build

make

>> run the below command to execute the program and send output to txt file

./lab3 NEWTON.PAS > ActualOutput.txt
